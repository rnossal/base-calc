var dec = document.querySelector("#dec"),
	bin = document.querySelector("#bin"),
	hex = document.querySelector("#hex"),
	oct = document.querySelector("#oct");

function convDec() {
	intParsed = parseInt(dec.value, 10);

	bin.value = intParsed.toString(2);
	hex.value = dec.value === '' ? '' : intParsed.toString(16);
	oct.value = intParsed.toString(8);
}
function convBin() {
	intParsed = parseInt(bin.value, 2);

	dec.value = intParsed;
	hex.value = bin.value === '' ? '' : intParsed.toString(16);
	oct.value = intParsed.toString(8);
}
function convHex() {
	intParsed = parseInt(hex.value, 16);

	dec.value = intParsed;
	bin.value = intParsed.toString(2);
	oct.value = intParsed.toString(8);
}
function convOct() {
	intParsed = parseInt(oct.value, 8);

	dec.value = intParsed;
	bin.value = intParsed.toString(2);
	hex.value = oct.value === '' ? '' : intParsed.toString(16);
}

dec.addEventListener('keyup', convDec);
bin.addEventListener('keyup', convBin);
hex.addEventListener('keyup', convHex);
oct.addEventListener('keyup', convOct);
dec.addEventListener('change', convDec);
bin.addEventListener('change', convBin);
hex.addEventListener('change', convHex);
oct.addEventListener('change', convOct);
